const express = require('express');
const app = express();
const port = process.env.PORT || 3000;

// Middleware to parse incoming form data


app.post('/Inregistrare', (req, res) => {
  try {
    const { username, password, role, email } = req.body;

    // Validate the request data (you can add your validation logic here)

    // Process, validate, and save this data to your database as needed
    // For example, you can use Mongoose if you're working with MongoDB or any other database library

    // Simulate an error for demonstration purposes (remove this in your production code)
    // throw new Error('An error occurred during registration');

    console.log('Received form data:');
    console.log('Username:', username);
    console.log('Password:', password);
    console.log('Role:', role);
    console.log('Email:', email);

    // Respond to the client with a success message
    res.json({ message: 'Data received successfully' });
  } catch (error) {
    console.error('Error during registration:', error);

    // Respond to the client with an error message
    res.status(500).json({ error: 'An error occurred during registration' });
  }
});
  

app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
