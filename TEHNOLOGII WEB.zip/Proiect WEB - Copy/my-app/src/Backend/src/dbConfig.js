const { Sequelize } = require('sequelize');
const env = require('dotenv');

env.config();

const db = new Sequelize({
    dialect: 'mysql',
    database: 'my_db',
    username: 'root',
    password: '123123',
    host: '127.0.0.1', // Nu include portul aici
    port: 9000,  
    logging: false,
    define: {
        timestamps: false,
        freezeTableName: true
    }
});
db.sync().then(() => {
    console.log("Toate modelele au fost sincronizate cu succes.");
});

module.exports = db;
