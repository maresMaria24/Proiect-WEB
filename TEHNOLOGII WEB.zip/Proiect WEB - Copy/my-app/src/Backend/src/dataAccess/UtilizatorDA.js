const Utilizator = require('../entities/Utilizator');

const db = require('../dbConfig');
const Sequelize = require('sequelize');

const Like = Sequelize.Op.like;
async function createUtilizator(utilizator) {
  return await Utilizator.create(utilizator);
}

async function getUtilizatori(utilizatorFilter) {
  if (!utilizatorFilter.take)
    utilizatorFilter.take = 10;

  if (!utilizatorFilter.skip)
    utilizatorFilter.skip = 0;

  let whereClause = {};
  if (utilizatorFilter.Name)
    whereClause.Name = { [Like]: `%${utilizatorFilter.Name}%` };

  if (utilizatorFilter.Email)
    whereClause.Email = { [Like]: `%${utilizatorFilter.Email}%` };

  return await Utilizator.findAndCountAll(
    {
      distinct: true,
      where: whereClause,
      limit: utilizatorFilter.take,
      offset: utilizatorFilter.skip * utilizatorFilter.take,
    });
}

async function getUtilizatorById(id) {
  return await Utilizator.findByPk(id);
}

async function deleteUtilizator(id) {
  let deleteElem = await Utilizator.findByPk(id);

  if (!deleteElem) {
    console.log("Acest element nu există și nu poate fi șters");
    return;
  }
  return await deleteElem.destroy();
}

async function updateUtilizator(utilizator, id) {
  const findUtilizator = await getUtilizatorById(id);

  if (!findUtilizator) {
    console.log("Acest utilizator nu există");
    return;
  }

  const t = await db.transaction()
  try {
    await findUtilizator.update(utilizator);

    await t.commit();

  } catch (e) {
    await t.rollback();
    throw e;
  }
}

module.exports = {
  createUtilizator,
  getUtilizatorById,
  getUtilizatori,
  deleteUtilizator,
  updateUtilizator
};
