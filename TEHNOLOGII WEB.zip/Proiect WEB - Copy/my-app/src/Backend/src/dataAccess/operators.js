import Sequelize from 'sequelize';

export const Like = Sequelize.Op.like;