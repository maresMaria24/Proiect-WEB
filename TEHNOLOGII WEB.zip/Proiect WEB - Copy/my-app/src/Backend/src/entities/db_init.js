const mysql = require('mysql2/promise');
const dotenv = require('dotenv');
const Utilizator = require('./Utilizator');
const Conferinta = require('./Conferinta');
const Feedback = require('./Feedback');
const Articol = require('./Articol');

//const Employee = require('./Employee');
//const Address = require('./Address');
//const { Addresses } = require('./dbConst');

dotenv.config();
/*
PORT=9000
DB_DATABASE="Database"
DB_USERNAME="root"
DB_PASSWORD="123123"
mysql.createConnection({
        user: process.env.DB_USERNAME,
        password: process.env.DB_PASSWORD,
        host: '127.0.0.1', // Nu include portul aici
        port: 9000  
    })


*/
function createDatabase() {   
    mysql.createConnection({
        database:'my_db',
        user: 'root',
        password: '123123',
        host: '127.0.0.1', // Nu include portul aici
        port: 9000,  
    })
    .then(() => {
        console.log(`Database ${process.env.DB_DATABASE} created or already exists.`);
    })  
    .catch(err => {
        console.warn(err.stack);
    });
 
}

function fkConfig() {
    /*Conferinta.belongsTo(Utilizator, {
        foreignKey: 'ID_Organizator',
        as: 'Organizator',
    });
    Articol.belongsTo(Utilizator, {
    foreignKey: 'ID_Autor',
    as: 'Autor',
    });
    Articol.belongsTo(Conferinta, {
    foreignKey: 'ID_Conferinta',
    as: 'Conferinta',
    });
    Conferinta.hasMany(Articol, {foreignKey : 'ID_Conferinta', as: 'Articole'});
    Feedback.belongsTo(Articol, {
        foreignKey: 'ID_Articol',
        as: 'Feedbacks',
        });
    Feedback.belongsTo(Utilizator, {
        foreignKey: 'ID_Reviewer',
        as: 'Reviews',
        });*/
        function fkConfig() {
            Conferinta.belongsTo(Utilizator, {
                foreignKey: 'ID_Organizator',
                as: 'Organizator',
            });
            Articol.belongsTo(Utilizator, {
                foreignKey: 'ID_Autor',
                as: 'Autor',
            });
            Articol.belongsTo(Conferinta, {
                foreignKey: 'ID_Conferinta',
                as: 'Conferinta',
            });
            Articol.belongsTo(Conferinta, {
                foreignKey: 'ID_Autor',
                as: 'Autor',
            });
            Conferinta.hasMany(Articol, {
                foreignKey: 'ID_Conferinta', // Aici trebuie să fie cheia străină din Articol
                as: 'Articole',
            });
            Articol.hasMany(Feedback, {foreignKey: 'ID_Feedback', as:'Feedbacks',});
            Feedback.belongsTo(Articol, {
                foreignKey: 'ID_Articol',
                as: 'FeedbackArt',
            });
            Feedback.belongsTo(Utilizator, {
                foreignKey: 'ID_Reviewer',
                as: 'Reviewer',
            });



            
        }
        
        
     
}

function db_init() {
    createDatabase();
    fkConfig();
}

module.exports = db_init;
