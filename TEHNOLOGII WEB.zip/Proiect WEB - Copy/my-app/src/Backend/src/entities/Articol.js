const db = require('../dbConfig');
const Sequelize = require('sequelize');

const Articol = db.define("Articol", {
    ID_Articol: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull: false
    },
    Titlu: {
        type: Sequelize.STRING,
        allowNull: false
    },
    Abstract: {
        type: Sequelize.TEXT,
        allowNull: false
    },
    ID_Autor: {
        type: Sequelize.INTEGER,
        allowNull: false,
        references: {
            model: 'Utilizator', // Numele tabelului articolului
            key: 'ID_Utilizator',
        }
    },
    ID_Conferinta: {
        type: Sequelize.INTEGER,
        allowNull: false,
        references: {
            model: 'Conferinta',
            key: 'ID_Conferință',
        }
    },
    ID_Feedback: {
        type: Sequelize.INTEGER,
        allowNull: false,
        references: {
            model: 'Feedback',
            key: 'ID_Feedback',
        }
    },
    Data_Submitere: {
        type: Sequelize.DATE,
        allowNull: false
    },
    //Fișier_Articol: {
      //  type: Sequelize.STRING, // Sau alt tip care se potrivește mai bine pentru link-uri
    //},
    Stare: {
        type: Sequelize.ENUM('Aprobat', 'In curs de review', 'Respins'),
        allowNull: false
    }
    // Adăugați aici orice alte câmpuri necesare
});
db.authenticate()
   .then(() => console.log('Conexiune reușită la baza de date.ARTICOL'))
   .catch(err => console.error('Nu s-a putut conecta la baza de date:', err));
 
module.exports = Articol;