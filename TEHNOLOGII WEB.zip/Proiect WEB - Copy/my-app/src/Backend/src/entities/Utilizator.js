const db = require('../dbConfig');
const Sequelize = require('sequelize');

const Utilizator = db.define("Utilizator", {
    ID_Utilizator: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull: false
    },
    Name: {
        type: Sequelize.STRING,
        allowNull: false
    },
    Email: {
        type: Sequelize.STRING,
        allowNull: false,
        unique: true
    },
    Password: {
        type: Sequelize.STRING,
        allowNull: false
    },
    Tip: {
        type: Sequelize.ENUM('Organizator', 'Reviewer', 'Autor'),
        allowNull: false
    },
    Informații_Profil: {
        type: Sequelize.TEXT,
        allowNull: true 
    }
});
db.authenticate()
   .then(() => console.log('Conexiune reușită la baza de date UTILIZATOR'))
   .catch(err => console.error('Nu s-a putut conecta la baza de date:', err));


module.exports = Utilizator;
