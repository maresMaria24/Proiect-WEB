const db = require('../dbConfig');
const Sequelize = require('sequelize');


const Conferinta = db.define("Conferinta", {
    ID_Conferință: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull: false
    },
    Nume: {
        type: Sequelize.STRING,
        allowNull: false
    },
    Descriere: {
        type: Sequelize.TEXT,
        allowNull: true // Presupunem că descrierea poate fi opțională
    },
    Data_Începerii: {
        type: Sequelize.DATE,
        allowNull: false
    },
    Data_Finalizării: {
        type: Sequelize.DATE,
        allowNull: false
    },
    Locație: {
        type: Sequelize.STRING,
        allowNull: true // Locația poate fi opțională, presupunând conferințe virtuale
    },
    ID_Organizator: {
        type: Sequelize.INTEGER,
        allowNull: false,
        references: {
            model: 'Utilizator', // Numele tabelului articolului
            key: 'ID_Utilizator',
        }
    },
    URL_Website: {
        type: Sequelize.STRING,
        allowNull: true // URL-ul website-ului poate fi opțional
    },
    Stare: {
        type: Sequelize.ENUM('Planificat', 'În Derulare', 'Finalizat'),
        allowNull: false
    }
    // Adăugați aici orice alte câmpuri necesare
});
db.authenticate()
   .then(() => console.log('Conexiune reușită la baza de date CONFERINTA'))
   .catch(err => console.error('Nu s-a putut conecta la baza de date:', err));



module.exports = Conferinta;
