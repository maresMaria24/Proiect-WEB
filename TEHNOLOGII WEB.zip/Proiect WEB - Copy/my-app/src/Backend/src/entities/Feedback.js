const db = require('../dbConfig');
const Sequelize = require('sequelize');

const Feedback= db.define("Feedback", {
    ID_Feedback: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull: false
    },
    ID_Articol: {
        type: Sequelize.INTEGER,
        allowNull: false,
        references: {
            model: 'Articol', // Numele tabelului articolului
            key: 'ID_Articol'
        }
    },
    ID_Reviewer: {
        type: Sequelize.INTEGER,
        allowNull: false,
        references: {
            model: 'Utilizator', // Numele tabelului reviewer-ului
            key: 'ID_Utilizator',
        }
    },
    Data_Alocării: {
        type: Sequelize.DATE,
        allowNull: false
    },
    Feedbacks: {
        type: Sequelize.TEXT,
        allowNull: true // Feedback-ul poate fi adăugat ulterior, deci poate fi opțional
    },
    Scor: {
        type: Sequelize.INTEGER,
        allowNull: true // Scorul este opțional
    },
    Stare_Review: {
        type: Sequelize.ENUM('Aprobat', 'Refuzat'),
        allowNull: false
    }
});
db.authenticate()
   .then(() => console.log('Conexiune reușită la baza de date.FEEDBACK'))
   .catch(err => console.error('Nu s-a putut conecta la baza de date:', err));

module.exports = Feedback;
