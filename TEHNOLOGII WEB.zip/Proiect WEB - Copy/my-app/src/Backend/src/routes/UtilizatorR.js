import express from 'express';
import { createUtilizator } from "./dataAccess/utilizatorDA";
const utilizatorRouter = express.Router();

utilizatorRouter.route('/utilizator').post(async (req, res) => {
  // Check if all required parameters are present in the request body
  const { name, password, email, role } = req.body;
  if (!name || !password || !email || !role) {
    return res.status(400).json({ error: 'All parameters (name, password, email, role) are required.' });
  }

  // Create an object for insertion into the database
  const utilizatorData = {
    name: name,
    password: password,
    email: email,
    role: role
  };

  try {
    const newUtilizator = await createUtilizator(utilizatorData);
    return res.status(201).json(newUtilizator);
  } catch (error) {
    return res.status(500).json({ error: 'An error occurred while creating the utilizator.' });
  }
});

// Rest of the routes remain unchanged for retrieving, updating, and deleting utilizators

export default utilizatorRouter;
