import React from 'react';
import {
  BrowserRouter as Router,
  Routes,
  Route,
  Link
} from 'react-router-dom';
import './App.css';
import { routes } from './routes.js';

function App() {
  return (
    <Router>
      <div className="App">
        <header className="App-header">
          
          {/* Navigation Menu */}
          <div>
          <ul>
  {routes.map((route) => (
    route.name !== 'Login' ? (
      <li key={route.path}>
        <Link to={route.path}>{route.name}</Link>
      </li>
    ) : null
  ))}
</ul>

          </div>
          <Routes>
            {routes.map((route) => (
              <Route
                key={route.path}
                path={route.path}
                element={<route.component />} // Render the component for each route
              />
            ))}
          </Routes>
        </header>
      </div>
    </Router>
  );
}

export default App;


/*

<Routes>
            <Route path="/conferences" element={<ConferencesPage />} />
            <Route path="/profile" element={<ProfilePage />} />
            <Route path="/" element={<HomePage />} />
            <Route path="/login" element={<Login />} />
          </Routes>
*/