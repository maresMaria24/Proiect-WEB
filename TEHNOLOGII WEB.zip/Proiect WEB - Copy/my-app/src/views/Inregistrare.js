import React, { useState } from 'react';
import './styles/auth.css';
import 'bootstrap/dist/css/bootstrap.min.css';



function Inregistrare() {
  const [formData, setFormData] = useState({
    username: '',
    email: '',
    password: '',
    role: 'autor', // Rolul implicit
  });

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData({ ...formData, [name]: value });    
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    console.log(formData);
    const dataToSend = {
        username: formData.username,
        email: formData.email,
        password:formData.password,
        role:formData.role,
      };
      const response = await fetch('http://localhost:3000/Inregistrare', {
        method: 'POST',
        body: JSON.stringify(dataToSend), // Convert the object to a JSON string
        headers: {
          'Content-Type': 'application/json', // Set the content type to JSON
        },
      });
   
};
  
  

  const renderForm = () => (
    <div className="container">
        <div className="content">
            <form onSubmit={handleSubmit}>
            <InputField label="Username" name="username" value={formData.username} onChange={handleChange} className="user" />
            <InputField label="Email" name="email" type="email" value={formData.email} onChange={handleChange} className="EmailI"/>
            <InputField label="Password" name="password" type="password" value={formData.password} onChange={handleChange} className="PassI" />
            <SelectField label="Rol" name="role" value={formData.role} onChange={handleChange} options={['autor', 'reviewer', 'organizator']} className="RoleI"/>
            <button type="submit" className="btn btn-light">Submit</button>
            </form>
        </div>
    </div>
  );

  return (
   renderForm()
  );
}

function InputField({ label, name, type = 'text', value, onChange, className }) {
    return (
      <div className="form-group row mb-3">
        <label className="col-sm-4 col-form-label">{label}:</label>
        <div className="col-sm-6">
          <input type={type} className={`form-control ${className}`} name={name} value={value} onChange={onChange} />
        </div>
      </div>
    );
  }
  
  function SelectField({ label, name, value, onChange, options, className }) {
    return (
      <div className="form-group row mb-3">
        <label className="col-sm-4 col-form-label">{label}:</label>
        <div className="col-sm-6">
          <select className={`form-control ${className}`} name={name} value={value} onChange={onChange}>
            {options.map(option => <option key={option} value={option}>{option}</option>)}
          </select>
        </div>
      </div>
    );
  }
  
export default Inregistrare;
