import React from 'react';

function Login() {
  return (
    <div>
      <h2>Login</h2>
      {/* Content for login page goes here */}
    </div>
  );
}

export default Login;
