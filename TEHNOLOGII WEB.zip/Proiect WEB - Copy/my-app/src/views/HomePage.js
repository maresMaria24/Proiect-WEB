import React from 'react';
import styles from './stan.module.css'; // Importă modulul CSS
import 'bootstrap/dist/css/bootstrap.min.css';

function HomePage() {
  return (
    <div id={styles.containere}> {/* Utilizează clasele din modulul CSS */}
      <div id={styles.contente}>
        <div className="row">
          <div className="align-items-center"><h3>Login</h3></div>
        </div>
        <div className="row">
          <div className="col-md-3">Username:</div>
          <div className="col-md-9"><input type="text" /></div>
        </div>
      </div>
    </div>
  );
}

export default HomePage;
