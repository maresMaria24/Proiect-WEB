
import './styles/auth.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import React, { useState } from 'react';

function Autentificare() {
  const [formData, setFormData] = useState({
    email: '',
    password: '',
  });

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    console.log(formData);
  
  };

  const renderForm = () => (
    <div className="container">
        <div className="content">
            <form onSubmit={handleSubmit}>
            <InputField label="Email" name="email" type="email" value={formData.email} onChange={handleChange} className="EmailI"/>
            <InputField label="Password" name="password" type="password" value={formData.password} onChange={handleChange} className="PassI" />
            <button type="submit" className="btn btn-light">Submit</button>
            </form>
        </div>
    </div>
  );

  return (
   renderForm()
  );
}

function InputField({ label, name, type = 'text', value, onChange, className }) {
    return (
      <div className="form-group row mb-3">
        <label className="col-sm-4 col-form-label">{label}:</label>
        <div className="col-sm-6">
          <input type={type} className={`form-control ${className}`} name={name} value={value} onChange={onChange} />
        </div>
      </div>
    );
  }
  
  function SelectField({ label, name, value, onChange, options, className }) {
    return (
      <div className="form-group row mb-3">
        <label className="col-sm-4 col-form-label">{label}:</label>
        <div className="col-sm-6">
          <select className={`form-control ${className}`} name={name} value={value} onChange={onChange}>
            {options.map(option => <option key={option} value={option}>{option}</option>)}
          </select>
        </div>
      </div>
    );
  }
  
export default Autentificare;

          