import Autentificare from "./views/Autentificare";
import Conference from "./views/ConferencesPage";
import HomePage from "./views/HomePage";
import Login from "./views/Login";
import ProfilePage from "./views/ProfilePage";
import Inregistrare from "./views/Inregistrare";
//import NotFound from "./views/NotFound";

export const routes = Object.freeze([
    {
        path:"/HomePage",
        component: HomePage,
        name: "Home"
    },
    {
        path:"/Conference",
        component: Conference,
        name: "Conferinte"
    },
    {
        path:"/ProfilePage",
        component: ProfilePage,
        name: "Pagina de profil"
    },
    {
        path:"/Inregistrare",
        component: Inregistrare,
        name: "Login",
    },
    {
        path:"/Autentificare",
        component: Autentificare,
        name: "Autentificare",
    } 
]);
export default routes;