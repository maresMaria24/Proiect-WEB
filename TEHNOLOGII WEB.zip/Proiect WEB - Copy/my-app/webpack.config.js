resolve: {
    fallback: {
      util: require.resolve('util/'),
      fs: require.resolve('fs'),
      path: require.resolve('path-browserify'),
      assert: require.resolve('assert/'),
      url: require.resolve('url/'),
    },
  },
  